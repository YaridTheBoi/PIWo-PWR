const Login = () => {

    return (
        <div className="App">
            <h2>Please log in</h2>
            <button>Login with big G</button>
        </div>
        );
}

export default Login;
